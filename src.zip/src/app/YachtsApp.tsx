import TreeDisplay from "../components/TreeDisplay"
import { useYachtGroupTree } from "../hooks/useYachtGroupTree"

export default function YachtsApp() {
  const { nodes, loading, error } = useYachtGroupTree()

  if (loading) {
    return <div style={{ padding: 20 }}>Loading yachts…</div>
  }

  if (error) {
    return (
      <div style={{ padding: 20, color: "red" }}>
        Failed to load yachts: {error}
      </div>
    )
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Yachts</h1>

      <TreeDisplay
        nodes={nodes}
        onSelect={(node) => {
          if (node.nodeType === "yacht") {
            console.log("Selected yacht:", node.meta)
          }
        }}
      />
    </div>
  )
}
