import { Routes, Route } from "react-router-dom";
import Desktop from "../app/Desktop";
import YachtsApp from "../app/YachtsApp";

export default function AppRoutes() {
  return (
    <Routes>
      <Route index element={<Desktop />} />
      <Route path="apps/yachts" element={<YachtsApp />} />
    </Routes>
  );
}
