import { useEffect, useState } from "react";
import { supabase } from "./lib/supabase";

import AppShell from "./app/AppShell";
import LoginPage from "./pages/LoginPage";
import AppRoutes from "../src/app/routes";

export default function App() {
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState<any>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
    return (
      <AppShell showLogout={false}>
        <div style={{ padding: 20 }}>Loading…</div>
      </AppShell>
    );
  }

  if (!session) {
    return (
      <AppShell showLogout={false}>
        <LoginPage />
      </AppShell>
    );
  }

  return (
    <AppShell showLogout={true}>
      <AppRoutes />
    </AppShell>
  );
}
